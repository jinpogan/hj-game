# hjgame
A python3 game. Python3 滑稽的游戏
THIS GAME WORKS IN MAC OSX OR LINUX WITHOUT ANY PROBLEM, IN WINDOWS, YOU NEED TO OPEN L.html TO VIEW THE LICENSE. MAYBE YOU NEED TO CHANGE THE LINE 111 INTO 'os.system("python op.py")' TO WORK ON WINDOWS.
# Support

You can support video wallpaper by just watching and 5 second ad. Or you can use Paypal

[AD](http://zipansion.com/20110541/thanks)

[Paypal](https://www.paypal.com/pools/c/86VkJFnIEp)
